from django.apps import AppConfig


class NaukriConfig(AppConfig):
    name = 'naukri'
